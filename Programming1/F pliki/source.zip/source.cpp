// Filip Jarzyna
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

struct DANA2 {
    bool boolType;
    unsigned short int uncharType;
    string floatType;
};

struct DANA {
    int intType;
    string strType;
    char charType;
    DANA2 buf1;
    DANA2 buf2;
    DANA2 buf3;
    DANA2 buf4;
};

bool BufCompare(DANA2 buf1, DANA2 buf2)
{
    return (buf1.uncharType == buf2.uncharType) && (buf1.floatType == buf2.floatType) && (buf1.boolType == buf2.boolType);
}

bool DanaCompare(DANA dana1, DANA dana2)
{
    // 1 d1 == d2
    // 0 d1 != d2
    bool isSame = 1;
    if (dana1.intType == dana2.intType) {
        if (dana1.strType == dana2.strType) {
            if (dana1.charType == dana2.charType) {
                if (BufCompare(dana1.buf1, dana2.buf1)) {
                    if (BufCompare(dana1.buf2, dana2.buf2)) {
                        if (BufCompare(dana1.buf3, dana2.buf3)) {
                            if (!(BufCompare(dana1.buf4, dana2.buf4))) {
                                isSame = false;
                            }
                        } else {
                            isSame = false;
                        }
                    } else {
                        isSame = false;
                    }
                } else {
                    isSame = false;
                }
            } else {
                isSame = false;
            }
        } else {
            isSame = false;
        }
    } else {
        isSame = false;
    }

    return isSame;
}

void ReadDana(fstream& dataFile, DANA& dana)
{
    dataFile >> dana.intType;
    dataFile >> dana.strType;
    dataFile >> dana.charType;
    dataFile >> dana.buf1.boolType;
    dataFile >> dana.buf1.uncharType;
    dataFile >> dana.buf1.floatType;
    dataFile >> dana.buf2.boolType;
    dataFile >> dana.buf2.uncharType;
    dataFile >> dana.buf2.floatType;
    dataFile >> dana.buf3.boolType;
    dataFile >> dana.buf3.uncharType;
    dataFile >> dana.buf3.floatType;
    dataFile >> dana.buf4.boolType;
    dataFile >> dana.buf4.uncharType;
    dataFile >> dana.buf4.floatType;
}

void PutDana(fstream& dataFile, DANA dana)
{
    dataFile << dana.intType << endl;
    dataFile << dana.strType << endl;
    dataFile << dana.charType << endl;
    dataFile << dana.buf1.boolType << endl;
    dataFile << dana.buf1.uncharType << endl;
    dataFile << dana.buf1.floatType << endl;
    dataFile << dana.buf2.boolType << endl;
    dataFile << dana.buf2.uncharType << endl;
    dataFile << dana.buf2.floatType << endl;
    dataFile << dana.buf3.boolType << endl;
    dataFile << dana.buf3.uncharType << endl;
    dataFile << dana.buf3.floatType << endl;
    dataFile << dana.buf4.boolType << endl;
    dataFile << dana.buf4.uncharType << endl;
    dataFile << dana.buf4.floatType;
}

void SymmetricDifference(string fileName1, string fileName2, string helpName)
{
    fstream fileA;
    fstream fileB;
    fstream helpf;
    DANA danaA;
    DANA danaB;

    // A += B \ A     H = A /\ B
    fileA.open(fileName1.c_str(), fstream::in | fstream::out | fstream::app);
    fileB.open(fileName2.c_str(), fstream::in);
    helpf.open(helpName.c_str(), fstream::out | fstream::trunc);

    if (fileA.good() && fileB.good() && helpf.good()) {
        fileB.seekg(0, fstream::beg);
        helpf.seekg(0, fstream::beg);
        while (true) {
            bool isInside = false;
            if (fileB.eof())
                break;
            ReadDana(fileB, danaB);
            fileA.seekg(0, fstream::beg);
            while (true) {
                if (fileA.eof())
                    break;
                ReadDana(fileA, danaA);
                if (DanaCompare(danaA, danaB)) { // dana1 == danaB
                    isInside = true;
                    break;
                }
            }
            if (isInside) {
                // H += A /\ B
                helpf.seekp(0, fstream::end);
                PutDana(helpf, danaB);
            } else {
                // A += B \ A
                fileA.seekg(0, fstream::end);
                fileA << endl;
                PutDana(fileA, danaB);
            }
        }
        fileA.close();
        fileB.close();
        helpf.close();
        fileB.open(fileName2.c_str(), fstream::out | fstream::trunc);
        helpf.open(helpName.c_str(), fstream::in);
        if (fileB.good() && helpf.good()) {

            while (true) {
                if (helpf.eof())
                    break;
                ReadDana(helpf, danaA);
                PutDana(fileB, danaA);
            }
        }
        fileB.close();
        helpf.close();
    } else {
        fileA.close();
        fileB.close();
        helpf.close();
    }
}

void SortCout(string fileName, string helpName1, string helpName2)
{
}

void SortInt(string fileName, string helpName1, string helpName2)
{
}

void SortString(string fileName, string helpName1, string helpName2)
{
}

/*
int main()
{
    SymmetricDifference("file1.txt", "file2.txt", "help.txt");
    return 0;
}
*/
